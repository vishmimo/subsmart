
import { GoogleGenAI, Type, Chat } from "@google/genai";
import { Subscription, Recommendation, FinancialHealth } from "../types";

// Initialize AI with secure platform API Key
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates initial subscription recommendations based on cost and usage.
 */
export const analyzeSubscriptions = async (subscriptions: Subscription[]): Promise<Recommendation[]> => {
  if (!subscriptions || subscriptions.length === 0) return [];

  const prompt = `
    Analyze these subscriptions for a user. 
    Look for high costs with low usage (usageLevel 0-100), redundant services, and potential downgrades.
    
    Subscriptions: ${JSON.stringify(subscriptions)}

    Return a list of recommendations in JSON format. 
    Include a 'confidence' score between 0 and 1 for each.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              subName: { type: Type.STRING },
              action: { type: Type.STRING, enum: ['Keep', 'Cancel', 'Downgrade', 'Review'] },
              reasoning: { type: Type.STRING },
              potentialSaving: { type: Type.NUMBER },
              confidence: { type: Type.NUMBER }
            },
            required: ['id', 'subName', 'action', 'reasoning', 'potentialSaving', 'confidence']
          }
        }
      }
    });

    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("AI Analysis failed:", error);
    return [];
  }
};

/**
 * Generates a high-level health report of the user's finances.
 */
export const generateHealthReport = async (subscriptions: Subscription[]): Promise<FinancialHealth> => {
  if (!subscriptions || subscriptions.length === 0) {
    return { score: 0, status: 'Critical', summary: 'No subscription data found to analyze.' };
  }

  const prompt = `
    Based on the following subscriptions, provide a "Financial Health Score" (0-100) and a concise summary (max 2 sentences) of their spending efficiency.
    Consider cost vs usage.
    
    Data: ${JSON.stringify(subscriptions)}
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            score: { type: Type.NUMBER },
            status: { type: Type.STRING, enum: ['Critical', 'Sub-optimal', 'Good', 'Excellent'] },
            summary: { type: Type.STRING }
          },
          required: ['score', 'status', 'summary']
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Health report generation failed:", error);
    return { score: 50, status: 'Sub-optimal', summary: 'Could not complete AI audit.' };
  }
};

/**
 * Creates a chat session for the Financial Advisor.
 */
export const createAdvisorChat = (subscriptions: Subscription[], health?: FinancialHealth): Chat => {
  return ai.chats.create({
    model: "gemini-3-flash-preview",
    config: {
      systemInstruction: `
        You are SubSmart AI, a world-class personal financial advisor specializing in subscription management.
        Current subscriptions: ${JSON.stringify(subscriptions)}.
        Current Health Status: ${JSON.stringify(health)}.
        Goal: Save money and optimize digital overhead.
        Be professional, slightly witty, and data-driven. Use the usageLevel (0-100) to justify all advice.
      `,
    },
  });
};

/**
 * Generates a visual health banner based on current financial status.
 */
export const generateHealthVisual = async (health: FinancialHealth): Promise<string | null> => {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash-image',
      contents: {
        parts: [
          {
            text: `A high-tech futuristic holographic data visualization representating a financial health status of "${health.status}" with a score of ${health.score}/100. Sleek UI design, cybernetic blue and emerald tones, 3D charts, glowing elements, 4k, minimalist aesthetic.`,
          },
        ],
      },
      config: {
        imageConfig: {
          aspectRatio: "16:9"
        }
      },
    });

    for (const part of response.candidates?.[0]?.content?.parts || []) {
      if (part.inlineData) {
        return `data:image/png;base64,${part.inlineData.data}`;
      }
    }
    return null;
  } catch (error) {
    console.error("Visual generation failed:", error);
    return null;
  }
};
