
import { Subscription } from "../types";

const CATEGORY_MAP: Record<string, Subscription['category']> = {
  'netflix': 'Entertainment',
  'spotify': 'Entertainment',
  'disney+': 'Entertainment',
  'hulu': 'Entertainment',
  'youtube': 'Entertainment',
  'hbo': 'Entertainment',
  'paramount': 'Entertainment',
  'canva': 'Productivity',
  'adobe': 'Productivity',
  'creative cloud': 'Productivity',
  'slack': 'Productivity',
  'notion': 'Productivity',
  'zoom': 'Productivity',
  'dropbox': 'Cloud Storage',
  'google one': 'Cloud Storage',
  'icloud': 'Cloud Storage',
  'box': 'Cloud Storage',
  'gym': 'Fitness',
  'peloton': 'Fitness',
  'strava': 'Fitness',
  'myfitnesspal': 'Fitness',
  'equinox': 'Fitness',
};

/**
 * Suggests a category based on the service name.
 * @param name The name of the subscription service.
 * @returns A matching category or 'Other' if no match is found.
 */
export const suggestCategory = (name: string): Subscription['category'] => {
  const normalized = name.toLowerCase();
  
  // Direct match search
  for (const [keyword, category] of Object.entries(CATEGORY_MAP)) {
    if (normalized.includes(keyword)) {
      return category;
    }
  }

  // Broad keyword matching
  if (normalized.includes('music') || normalized.includes('video') || normalized.includes('stream') || normalized.includes('tv')) {
    return 'Entertainment';
  }
  if (normalized.includes('storage') || normalized.includes('drive') || normalized.includes('cloud')) {
    return 'Cloud Storage';
  }
  if (normalized.includes('work') || normalized.includes('tool') || normalized.includes('design')) {
    return 'Productivity';
  }
  if (normalized.includes('health') || normalized.includes('fit') || normalized.includes('yoga')) {
    return 'Fitness';
  }

  return 'Other';
};
