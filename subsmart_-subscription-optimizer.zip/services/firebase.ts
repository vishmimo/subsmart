
import { initializeApp, getApp, getApps } from 'firebase/app';
import { getFirestore, doc, setDoc, getDoc, Firestore } from 'firebase/firestore';
import { Subscription } from '../types';

/**
 * Hardcoded Cloud Telemetry Configuration
 * Provided by the user for subsmart-ea2bd instance.
 */
const firebaseConfig = {
  apiKey: "AIzaSyA0HJYBM-RsZzkFMwNkm_KxLuLjLFLjsfM",
  authDomain: "subsmart-ea2bd.firebaseapp.com",
  projectId: "subsmart-ea2bd",
  storageBucket: "subsmart-ea2bd.firebasestorage.app",
  messagingSenderId: "205047771646",
  appId: "1:205047771646:web:17fc39876770f2491ed0af",
  measurementId: "G-9E9PNSMVMS"
};

let db: Firestore | null = null;
let isMockMode = false;

// Initialize Firebase with failover to local vault
try {
  if (!getApps().length) {
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app);
  } else {
    db = getFirestore(getApp());
  }
} catch (error) {
  console.warn("Cloud Protocol Failure. Falling back to local encrypted vault.", error);
  isMockMode = true;
}

const USER_ID = 'primary-node-user'; 
const LOCAL_STORAGE_KEY = 'subsmart_registry_cache';

/**
 * Synchronize registry state to the cloud vault.
 */
export const saveSubscriptionsToFirebase = async (subs: Subscription[]) => {
  // Always update local cache first
  localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(subs));
  
  if (isMockMode || !db) return;
  
  try {
    const userDocRef = doc(db, 'users', USER_ID);
    await setDoc(userDocRef, { 
      subscriptions: subs, 
      lastUpdated: new Date().toISOString(),
      metadata: { 
        version: '1.0.3',
        source: 'SubSmart Terminal'
      }
    }, { merge: true });
  } catch (e: any) {
    console.error("Cloud Telemetry Sync Interrupted:", e.message);
  }
};

/**
 * Retrieve registry state from cloud or local failover.
 */
export const loadSubscriptionsFromFirebase = async (): Promise<Subscription[] | null> => {
  const localData = localStorage.getItem(LOCAL_STORAGE_KEY);
  const localSubs = localData ? JSON.parse(localData) : null;
  
  if (isMockMode || !db) return localSubs;
  
  try {
    const userDocRef = doc(db, 'users', USER_ID);
    const docSnap = await getDoc(userDocRef);
    if (docSnap.exists()) {
      return docSnap.data().subscriptions;
    }
  } catch (e: any) {
    return localSubs;
  }
  return localSubs;
};

/**
 * Monitor system connectivity status.
 */
export const getCloudStatus = () => ({
  isCloudActive: !isMockMode && !!db,
  provider: isMockMode ? 'Secure Local Vault' : `Cloud (${firebaseConfig.projectId})`
});
