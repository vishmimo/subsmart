
import React from 'react';

interface AdProps {
  type: 'banner' | 'square' | 'native';
}

export const AdBanner: React.FC<AdProps> = ({ type }) => {
  const handleAction = (toolName: string) => {
    alert(`Initializing ${toolName} Protocol...\nThis module is scheduled for the next system update.`);
  };

  if (type === 'banner') {
    return (
      <div 
        onClick={() => handleAction('Secure Vault Plus')}
        className="w-full bg-slate-100 dark:bg-slate-900/50 border border-slate-200 dark:border-slate-800 rounded-xl p-3 my-6 flex items-center justify-between group cursor-pointer hover:bg-white dark:hover:bg-slate-800 transition-colors"
      >
        <div className="flex items-center gap-3">
          <div className="bg-slate-200 dark:bg-slate-800 text-[10px] font-bold text-slate-500 dark:text-slate-400 px-1 rounded border border-slate-300 dark:border-slate-700">AD</div>
          <div className="w-10 h-10 bg-blue-100 dark:bg-blue-900/30 rounded flex items-center justify-center text-xl">🛡️</div>
          <div>
            <p className="text-sm font-bold text-slate-800 dark:text-slate-200">Secure Vault Plus</p>
            <p className="text-xs text-slate-500 dark:text-slate-400">Encrypt your cloud backups.</p>
          </div>
        </div>
        <button className="bg-slate-900 dark:bg-blue-600 text-white text-[10px] font-black uppercase px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors">Secure</button>
      </div>
    );
  }

  if (type === 'native') {
    return (
      <div 
        onClick={() => handleAction('Equity Manager AI')}
        className="bg-amber-50 dark:bg-amber-900/10 border border-amber-100 dark:border-amber-500/30 rounded-2xl p-5 my-6 relative overflow-hidden group cursor-pointer"
      >
        <div className="flex gap-4">
          <div className="w-12 h-12 bg-white dark:bg-slate-800 rounded-xl shadow-sm flex items-center justify-center text-2xl">💹</div>
          <div className="flex-1">
            <h4 className="font-black text-amber-900 dark:text-amber-400 text-sm">Equity Manager AI</h4>
            <p className="text-[11px] text-amber-800/70 dark:text-amber-300/60 mb-2 leading-tight">Link your portfolio for overview.</p>
            <button className="text-[9px] font-black text-amber-700 dark:text-amber-500 uppercase tracking-widest hover:underline flex items-center gap-1">
              Connect AI
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-slate-50/50 dark:bg-slate-900/20 border border-slate-200 dark:border-slate-800 rounded-2xl flex flex-col items-center justify-center p-4 text-center transition-all hover:bg-white dark:hover:bg-slate-900/40">
      <div className="text-[8px] font-black text-slate-400 dark:text-slate-600 mb-1.5 uppercase tracking-[0.3em]">AI Suggested</div>
      <div className="text-2xl mb-2">🏠</div>
      <p className="font-black text-slate-700 dark:text-slate-300 text-[10px] uppercase tracking-wider">Rent Optimizer</p>
      <p className="text-[9px] text-slate-400 dark:text-slate-500 mt-1 mb-3 leading-tight max-w-[140px]">Split household overhead with automated sync.</p>
      <button 
        onClick={() => handleAction('Rent Optimizer')}
        className="w-full py-2 bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl text-[9px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest hover:bg-blue-600 hover:text-white hover:border-blue-600 transition-all"
      >
        Enable Tool
      </button>
    </div>
  );
};
