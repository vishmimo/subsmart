
import React from 'react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, Legend } from 'recharts';
import { Subscription } from '../types';

interface Props {
  subscriptions: Subscription[];
  isDark: boolean;
}

export const Analytics: React.FC<Props> = ({ subscriptions, isDark }) => {
  const categoryData = subscriptions.reduce((acc: any[], sub) => {
    const existing = acc.find(i => i.name === sub.category);
    if (existing) {
      existing.value += sub.amount;
    } else {
      acc.push({ name: sub.category, value: sub.amount });
    }
    return acc;
  }, []);

  const usageData = subscriptions.map(sub => ({
    name: sub.name,
    usage: sub.usageLevel,
    cost: sub.amount
  }));

  const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
  const textColor = isDark ? '#94a3b8' : '#64748b';
  const gridColor = isDark ? '#1e293b' : '#f1f5f9';

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-10 animate-fade-in">
      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <h3 className="text-sm font-black uppercase tracking-widest mb-6 text-slate-400 dark:text-slate-500">Portfolio Breakdown</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={categoryData}
                cx="50%"
                cy="50%"
                innerRadius={60}
                outerRadius={80}
                paddingAngle={5}
                dataKey="value"
                stroke="none"
              >
                {categoryData.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: isDark ? '#0f172a' : '#ffffff', 
                  border: 'none',
                  borderRadius: '12px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                  fontSize: '10px',
                  fontWeight: 'bold',
                  color: textColor
                }} 
              />
              <Legend wrapperStyle={{ fontSize: '9px', fontWeight: 'bold', paddingTop: '10px' }} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-200 dark:border-slate-800 shadow-sm overflow-hidden">
        <h3 className="text-sm font-black uppercase tracking-widest mb-6 text-slate-400 dark:text-slate-500">Efficiency Matrix</h3>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={usageData}>
              <XAxis 
                dataKey="name" 
                tick={{ fontSize: 9, fill: textColor, fontWeight: 'bold' }} 
                axisLine={false} 
                tickLine={false}
              />
              <YAxis 
                tick={{ fontSize: 9, fill: textColor, fontWeight: 'bold' }} 
                axisLine={false} 
                tickLine={false}
              />
              <Tooltip 
                cursor={{ fill: isDark ? 'rgba(255,255,255,0.05)' : 'rgba(0,0,0,0.02)' }}
                contentStyle={{ 
                  backgroundColor: isDark ? '#0f172a' : '#ffffff', 
                  border: 'none',
                  borderRadius: '12px',
                  boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1)',
                  fontSize: '10px',
                  fontWeight: 'bold'
                }}
              />
              <Legend wrapperStyle={{ fontSize: '9px', fontWeight: 'bold' }} />
              <Bar dataKey="usage" name="Usage %" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={20} />
              <Bar dataKey="cost" name="Cost ($)" fill={isDark ? '#334155' : '#cbd5e1'} radius={[6, 6, 0, 0]} barSize={20} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
};
