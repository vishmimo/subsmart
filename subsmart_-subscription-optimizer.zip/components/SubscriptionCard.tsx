import React, { useState } from 'react';
import { Subscription } from '../types';

interface Props {
  sub: Subscription;
  onDelete: (id: string) => void;
  onUpdateCategory: (id: string, category: Subscription['category']) => void;
  onLink: (id: string) => void;
}

const CATEGORIES: Subscription['category'][] = ['Entertainment', 'Productivity', 'Fitness', 'Cloud Storage', 'Other'];

export const SubscriptionCard: React.FC<Props> = ({ sub, onDelete, onUpdateCategory, onLink }) => {
  const [isEditingCategory, setIsEditingCategory] = useState(false);
  const [isPurchasing, setIsPurchasing] = useState(false);

  const getUsageColor = (level: number) => {
    if (level < 30) return 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400';
    if (level < 60) return 'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400';
    return 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400';
  };

  const handlePurchase = () => {
    setIsPurchasing(true);
    setTimeout(() => {
      onLink(sub.id);
      setIsPurchasing(false);
    }, 1200);
  };

  const daysRemaining = (sub.id.charCodeAt(0) % 28) + 1;

  return (
    <div className="bg-white dark:bg-slate-900 rounded-3xl shadow-sm border border-slate-200 dark:border-slate-800 p-6 hover:shadow-xl transition-all duration-300 group relative flex flex-col h-full">
      {sub.isLinked && (
        <div className="absolute top-0 right-0 bg-blue-600 text-white text-[9px] font-black px-3 py-1.5 rounded-bl-xl z-10">
          SECURE LINK
        </div>
      )}
      
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-slate-50 dark:bg-slate-800 flex items-center justify-center text-2xl shadow-inner border border-slate-100 dark:border-slate-700 group-hover:scale-105 transition-transform">
            {sub.icon || '📦'}
          </div>
          <div>
            <h3 className="font-black text-slate-900 dark:text-slate-100 text-base tracking-tight">{sub.name}</h3>
            <div className="mt-1">
              {isEditingCategory ? (
                <select 
                  autoFocus
                  className="text-[9px] font-black px-2 py-0.5 bg-blue-50 dark:bg-blue-900/40 text-blue-700 dark:text-blue-400 rounded-lg outline-none"
                  value={sub.category}
                  onChange={(e) => {
                    onUpdateCategory(sub.id, e.target.value as Subscription['category']);
                    setIsEditingCategory(false);
                  }}
                  onBlur={() => setIsEditingCategory(false)}
                >
                  {CATEGORIES.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
              ) : (
                <button 
                  onClick={() => setIsEditingCategory(true)}
                  className="text-[8px] text-slate-500 font-black px-2 py-0.5 bg-slate-100 dark:bg-slate-800 rounded-md hover:bg-slate-200 uppercase tracking-widest"
                >
                  {sub.category}
                </button>
              )}
            </div>
          </div>
        </div>
        <button 
          onClick={() => onDelete(sub.id)}
          className="text-slate-300 hover:text-red-500 transition-all p-1.5"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
        </button>
      </div>

      <div className="flex justify-between items-end mb-4">
        <div>
          <p className="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
            {sub.currency}{sub.amount.toFixed(2)}
            <span className="text-[10px] font-bold text-slate-400 ml-1 uppercase">
              {sub.billingCycle === 'monthly' ? 'p/m' : 'p/y'}
            </span>
          </p>
          <p className="text-[9px] font-black text-blue-500 uppercase mt-1">Next: {daysRemaining} days</p>
        </div>
        <div className="px-3 py-1 rounded-xl text-[9px] font-black uppercase tracking-widest bg-slate-50 dark:bg-slate-800 text-slate-500 border border-slate-200 dark:border-slate-700">
          {sub.usageLevel}% Utility
        </div>
      </div>

      <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden mb-6">
        <div 
          className={`h-full rounded-full transition-all duration-1000 ${
            sub.usageLevel < 30 ? 'bg-red-500' : 
            sub.usageLevel < 60 ? 'bg-amber-400' : 
            'bg-blue-500'
          }`} 
          style={{ width: `${sub.usageLevel}%` }}
        />
      </div>

      <div className="mt-auto">
        {!sub.isLinked ? (
          <button 
            onClick={handlePurchase}
            disabled={isPurchasing}
            className={`w-full py-3 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all flex items-center justify-center gap-2 border ${
              isPurchasing 
              ? 'bg-slate-100 text-slate-400 border-slate-200 cursor-not-allowed' 
              : 'bg-blue-600 hover:bg-blue-700 text-white border-blue-700 active:scale-[0.97]'
            }`}
          >
            {isPurchasing ? 'Validating...' : 'Secure Node'}
          </button>
        ) : (
          <div className="flex items-center justify-center py-3 bg-emerald-50 dark:bg-emerald-900/10 border border-emerald-100 dark:border-emerald-500/20 rounded-xl text-[9px] font-black text-emerald-600 uppercase tracking-widest">
            <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
            Operational
          </div>
        )}
      </div>
    </div>
  );
};